public interface Observador { //motor
    public void update(); //actualiza cuando el sujero lo notifique o dispare un evento
    
}
