public interface SujetoObservable { //Acelerador
    public void notificar();//avisa que estan pisando el acelerador y hay que encender el motor
}
