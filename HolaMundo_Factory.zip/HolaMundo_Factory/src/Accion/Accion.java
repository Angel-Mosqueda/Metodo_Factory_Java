package Accion;



public interface Accion {
    
    public void saludar();
    
    public void despedirse();
    
    public String tipo();
}
