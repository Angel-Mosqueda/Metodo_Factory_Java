package Commands;

/**
 *
 * @author Angel
 */
public interface Operacion {
    void execute();
}
